// js/applications.js

// For employer: fetch internships posted by this employer then their applications
async function loadEmployerApplications(containerId='applications-list'){
  if(!requireAuth()) return;
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = '<p class="muted">Loading…</p>';
  try{
    // fetch all internships then filter by employer id
    const internships = await apiFetch('/internships/all');
    const myId = localStorage.getItem('user_id');
    const myInterns = internships.filter(i => String(i.employer_id) === String(myId) || String(i.employer_id) === String(parseInt(myId)));
    if(!myInterns.length) { el.innerHTML = '<p class="muted">You have not posted any internships yet.</p>'; return; }

    let html = '';
    for(const intern of myInterns){
      const apps = await apiFetch(`/applications/internship/${intern.id}`);
      html += `<div class="form-card"><h3 style="margin-top:0">${escapeHtml(intern.title)}</h3>`;
      if(!apps.length) html += `<p class="muted">No applications yet.</p>`;
      else{
        html += apps.map(a => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-top:1px solid #f1f5f9">
            <div>
              <strong>${escapeHtml(a.student_name || 'Student')}</strong> <div class="muted">${escapeHtml(a.university||'')}</div>
              <div><a href="${escapeHtml(a.resume_link||'#')}" target="_blank">View resume</a></div>
            </div>
            <div style="text-align:right">
              <div class="muted">Status: <strong>${escapeHtml(a.status)}</strong></div>
              <div style="margin-top:8px">
                <button class="btn-small" onclick="updateApplication(${a.id}, 'shortlisted')">Shortlist</button>
                <button class="btn-small" onclick="updateApplication(${a.id}, 'selected')">Select</button>
                <button class="btn-small" onclick="updateApplication(${a.id}, 'rejected')">Reject</button>
              </div>
            </div>
          </div>
        `).join('');
      }
      html += `</div>`;
    }
    el.innerHTML = html;
  }catch(err){
    el.innerHTML = `<div class="form-card"><p class="error">${escapeHtml(err.message)}</p></div>`;
  }
}

// update status endpoint
async function updateApplication(appId, status){
  try{
    await apiFetch(`/applications/update/${appId}`, { method:'PUT', body: JSON.stringify({ status })});
    alert('Status updated');
    if(document.getElementById('applications-list')) loadEmployerApplications('applications-list');
  }catch(err){ alert('Failed: '+err.message) }
}

// student view: fetch my applications
async function loadMyApplications(containerId='my-applications'){
  if(!requireAuth()) return;
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = '<p class="muted">Loading…</p>';
  try{
    const myId = localStorage.getItem('user_id');
    const apps = await apiFetch(`/applications/student/${myId}`);
    if(!apps.length){ el.innerHTML = '<p class="muted">No applications found.</p>'; return; }
    el.innerHTML = apps.map(a => `
      <div class="form-card" style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <h4 style="margin:0">${escapeHtml(a.title || 'Internship')}</h4>
          <div class="muted">${escapeHtml(a.applied_at || '')}</div>
        </div>
        <div>
          <div class="muted">Status: <strong>${escapeHtml(a.status)}</strong></div>
        </div>
      </div>
    `).join('');
  }catch(err){
    el.innerHTML = `<div class="form-card"><p class="error">${escapeHtml(err.message)}</p></div>`;
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  if(document.getElementById('applications-list')) loadEmployerApplications();
  if(document.getElementById('my-applications')) loadMyApplications();
});
