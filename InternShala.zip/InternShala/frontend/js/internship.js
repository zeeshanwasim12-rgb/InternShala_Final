// js/internship.js
// Requires apiFetch from main.js

async function loadInternships(containerId='internships-list'){
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = '<p class="muted">Loading internships…</p>';
  try{
    const data = await apiFetch('/internships/all');
    if(!Array.isArray(data) || data.length===0){
      el.innerHTML = `<div class="form-card center"><p class="muted">No internships available right now.</p></div>`;
      return;
    }
    el.innerHTML = data.map(i => `
      <div class="form-card" style="display:flex;gap:16px;align-items:flex-start">
        <div style="flex:1">
          <h3 style="margin:0;color:${'var(--primary)'}">${escapeHtml(i.title)}</h3>
          <p class="muted">${escapeHtml(i.description || '')}</p>
          <p style="margin:6px 0"><strong>Skills:</strong> ${escapeHtml(i.skills_required || '—')}</p>
          <p style="margin:6px 0"><strong>Stipend:</strong> ${escapeHtml(i.stipend || '—')}</p>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn-primary" onclick="applyToInternship(${i.id})">Apply</button>
        </div>
      </div>
    `).join('');
  }catch(err){
    el.innerHTML = `<div class="form-card center"><p class="error">Error: ${escapeHtml(err.message)}</p></div>`;
  }
}

async function applyToInternship(internshipId){
  if(!requireAuth()) return;
  const student_id = localStorage.getItem('user_id') || null;
  const resume_link = prompt("Paste your resume URL (Google Drive link or file URL) — leave blank to upload later:");
  if(!resume_link) { alert('Application cancelled'); return; }
  try{
    await apiFetch('/applications/apply', { method:'POST', body: JSON.stringify({ student_id, internship_id: internshipId, resume_link })});
    alert('Applied successfully');
  }catch(err){
    alert('Failed to apply: ' + err.message);
  }
}

// small helper
function escapeHtml(s){ if(!s) return ''; return String(s).replace(/[&<>"'`]/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

// auto-load internships where appropriate
document.addEventListener('DOMContentLoaded', ()=>{ if(document.getElementById('internships-list')) loadInternships(); });
