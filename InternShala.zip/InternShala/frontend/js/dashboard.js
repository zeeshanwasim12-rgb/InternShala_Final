// dashboard.js
document.addEventListener("DOMContentLoaded", () => {
  fetchInternships();
  fetchApplications();
});

async function fetchInternships() {
  const container = document.getElementById("internships-container");
  try {
    const res = await fetch("http://127.0.0.1:5000/api/internships");
    if (!res.ok) throw new Error("Failed to fetch internships");
    const data = await res.json();
    container.innerHTML = data.length
      ? data.map(i => `
        <div class="card-container">
          <h4>${i.title}</h4>
          <p>${i.description}</p>
          <button onclick="applyInternship(${i.id})">Apply</button>
        </div>`).join("")
      : "<p>No internships available.</p>";
  } catch (err) {
    container.innerHTML = `<p style="color:red;">Error: ${err.message}</p>`;
  }
}

async function fetchApplications() {
  const container = document.getElementById("applications-container");
  try {
    const res = await fetch("http://127.0.0.1:5000/api/applications");
    if (!res.ok) throw new Error("Failed to fetch applications");
    const data = await res.json();
    container.innerHTML = data.length
      ? data.map(a => `
        <div class="card-container">
          <h4>${a.internship_title}</h4>
          <p>Status: ${a.status}</p>
        </div>`).join("")
      : "<p>No applications found.</p>";
  } catch (err) {
    container.innerHTML = `<p style="color:red;">${err.message}</p>`;
  }
}
