const leaderboardList = document.getElementById("leaderboard-list");

// Example mock data — replace this with API call later
const sampleData = [
  { name: "Zeeshan Wasim", university: "MIT ADT Pune", total_points: 95, ai_score: 91, internships_done: 6, applications: 14 },
  { name: "Aarav Sharma", university: "IIT Delhi", total_points: 89, ai_score: 88, internships_done: 5, applications: 10 },
  { name: "Ananya Mehta", university: "BITS Pilani", total_points: 83, ai_score: 85, internships_done: 4, applications: 8 },
  { name: "Riya Verma", university: "VIT Vellore", total_points: 78, ai_score: 80, internships_done: 3, applications: 6 },
  { name: "Arjun Nair", university: "SRM University", total_points: 70, ai_score: 75, internships_done: 2, applications: 5 },
  { name: "Neha Kapoor", university: "Amity University", total_points: 65, ai_score: 68, internships_done: 1, applications: 3 },
];

function getBadge(rank, internships) {
  if (rank === 1) return '<span class="badge gold">🥇 Gold</span>';
  if (rank === 2) return '<span class="badge silver">🥈 Silver</span>';
  if (rank === 3) return '<span class="badge bronze">🥉 Bronze</span>';
  if (internships >= 5) return '<span class="badge expert">Expert</span>';
  if (internships >= 3) return '<span class="badge pro">Pro</span>';
  return '<span class="badge rookie">Rookie</span>';
}

function loadLeaderboard() {
  leaderboardList.innerHTML = sampleData.map((user, i) => `
    <div class="leaderboard-row fade-in" style="animation-delay:${i * 0.1}s">
      <span>#${i + 1}</span>
      <span>${user.name}</span>
      <span>${user.university}</span>
      <span>${user.internships_done}</span>
      <span>${user.applications}</span>
      <span>${user.total_points}</span>
      <span>${user.ai_score}</span>
      <span>${getBadge(i + 1, user.internships_done)}</span>
    </div>
  `).join("");
}

document.addEventListener("DOMContentLoaded", loadLeaderboard);
