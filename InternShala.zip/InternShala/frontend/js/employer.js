document.addEventListener("DOMContentLoaded", () => {
  fetchInternships();

  document.getElementById("postForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const internship = {
      title: document.getElementById("title").value,
      description: document.getElementById("description").value,
      duration: document.getElementById("duration").value,
      stipend: document.getElementById("stipend").value,
      location: document.getElementById("location").value,
    };

    const res = await fetch("http://127.0.0.1:5000/api/internships", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(internship),
    });
    const data = await res.json();
    alert(data.message || "Internship posted successfully!");
    fetchInternships();
    e.target.reset();
  });
});

async function fetchInternships() {
  const container = document.getElementById("posted-internships");
  try {
    const res = await fetch("http://127.0.0.1:5000/api/internships/employer");
    const data = await res.json();

    container.innerHTML = data.length
      ? data.map(i => `
        <div class="internship-card">
          <h4>${i.title}</h4>
          <p>${i.description}</p>
          <p><strong>Duration:</strong> ${i.duration}</p>
          <p><strong>Location:</strong> ${i.location}</p>
        </div>
      `).join("")
      : "<p>No internships posted yet.</p>";
  } catch (err) {
    container.innerHTML = `<p style="color:red;">Error fetching internships.</p>`;
  }
}
