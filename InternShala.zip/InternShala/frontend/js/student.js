document.addEventListener("DOMContentLoaded", () => {
  fetchInternships();
  fetchApplications();
});

async function fetchInternships() {
  const list = document.getElementById("internship-list");
  try {
    const res = await fetch("http://127.0.0.1:5000/api/internships");
    const data = await res.json();

    list.innerHTML = data.length
      ? data.map(i => `
        <div class="card">
          <h4>${i.title}</h4>
          <p>${i.description}</p>
          <p><strong>Duration:</strong> ${i.duration}</p>
          <button onclick="applyInternship(${i.id})">Apply</button>
        </div>
      `).join("")
      : "<p>No internships available.</p>";
  } catch (err) {
    list.innerHTML = `<p style="color:red;">Error fetching internships</p>`;
  }
}

async function fetchApplications() {
  const list = document.getElementById("application-list");
  try {
    const res = await fetch("http://127.0.0.1:5000/api/applications");
    const data = await res.json();

    list.innerHTML = data.length
      ? data.map(a => `
        <div class="card">
          <h4>${a.internship_title}</h4>
          <p>Status: ${a.status}</p>
        </div>
      `).join("")
      : "<p>No applications yet.</p>";
  } catch (err) {
    list.innerHTML = `<p style="color:red;">Error loading applications</p>`;
  }
}

async function applyInternship(id) {
  const res = await fetch("http://127.0.0.1:5000/api/applications/apply", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ internship_id: id }),
  });
  const data = await res.json();
  alert(data.message || "Application submitted!");
  fetchApplications();
}
