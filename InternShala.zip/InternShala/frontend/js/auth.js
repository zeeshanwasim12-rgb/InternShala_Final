// auth.js

const API_URL = "http://127.0.0.1:5000/api/auth";


document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const msg = document.getElementById("loginMsg");

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();

      msg.textContent = "Logging in...";
      msg.style.color = "#007bff";

      try {
        const res = await fetch("http://127.0.0.1:5000/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        });

        const data = await res.json();

        if (res.ok) {
          msg.textContent = "Login successful! Redirecting...";
          msg.style.color = "green";
          localStorage.setItem("token", data.token);
          localStorage.setItem("role", data.role);
          setTimeout(() => {
            window.location.href = data.role === "employer" ? "employer.html" : "dashboard.html";
          }, 1000);
        } else {
          msg.textContent = data.error || "Invalid credentials";
          msg.style.color = "red";
        }
      } catch (err) {
        msg.textContent = "Server connection failed.";
        msg.style.color = "red";
      }
    });
  }
});
