// js/main.js
const API_BASE = "http://127.0.0.1:5000/api"; // change if needed

function getToken(){ return localStorage.getItem("token") || null }
function setAuth(user){ // user: { token, user_id, role, name }
  localStorage.setItem("token", user.token);
  localStorage.setItem("user_id", user.user_id);
  localStorage.setItem("user_role", user.role || "");
  localStorage.setItem("user_name", user.name || "");
}
function clearAuth(){
  localStorage.removeItem("token");
  localStorage.removeItem("user_id");
  localStorage.removeItem("user_role");
  localStorage.removeItem("user_name");
}

// generic fetch wrapper
async function apiFetch(path, opts = {}){
  const url = API_BASE + path;
  const headers = opts.headers || {};
  if(!headers["Content-Type"] && !(opts.body instanceof FormData) && opts.body) headers["Content-Type"] = "application/json";
  const token = getToken();
  if(token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(url, {...opts, headers});
  const text = await res.text();
  let data;
  try{ data = text ? JSON.parse(text) : {}; } catch(e){ data = { raw: text }; }
  if(!res.ok) throw new Error(data.error || data.message || (data.raw || "API error"));
  return data;
}

// Basic UI helpers
function requireAuth(redirectTo='login.html'){
  if(!getToken()){
    window.location.href = redirectTo;
    return false;
  }
  return true;
}

function logoutAndRedirect(){
  clearAuth();
  window.location.href = "login.html";
}

// attach logout button globally if present
document.addEventListener('click', e=>{
  if(e.target && e.target.matches && e.target.matches('.logoutBtn')){
    logoutAndRedirect();
  }
});
