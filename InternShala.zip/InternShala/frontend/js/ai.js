const API_URL = "http://127.0.0.1:5000/api/ai";

async function uploadResume() {
  const resumeText = document.getElementById("resumeText").value.trim();
  const aiResultDiv = document.getElementById("aiResult");
  const userId = localStorage.getItem("user_id");

  if (!resumeText) {
    alert("Please paste your resume text first!");
    return;
  }

  try {
    const res = await fetch(`${API_URL}/upload_resume`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        user_id: userId || 1, // fallback for demo
        resume_text: resumeText
      })
    });

    const data = await res.json();

    aiResultDiv.style.display = "block";
    aiResultDiv.innerHTML = `
      <h3>AI Resume Evaluation</h3>
      <p><strong>AI Score:</strong> ${data.score || "N/A"}</p>
      <p><strong>Suggestions:</strong></p>
      <pre>${data.suggestions || "No suggestions available."}</pre>
    `;
  } catch (err) {
    aiResultDiv.style.display = "block";
    aiResultDiv.innerHTML = `<p style="color:red;">Error analyzing resume. Please try again later.</p>`;
  }
}
