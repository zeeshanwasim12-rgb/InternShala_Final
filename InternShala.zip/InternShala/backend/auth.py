from flask import Blueprint, request, jsonify, current_app
from models import create_user, get_user_by_email, get_user_by_id
from utils.helpers import hash_password, verify_password, create_token, decode_token

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    name = data.get('name'); email = data.get('email'); password = data.get('password')
    role = data.get('role', 'student'); university = data.get('university')
    if not (name and email and password):
        return jsonify({"error":"Missing fields"}), 400
    if get_user_by_email(email):
        return jsonify({"error":"Email already registered"}), 400
    pw_hash = hash_password(password)
    user_id = create_user(name, email, pw_hash, role, university)
    # create leaderboard initial row
    from models import update_leaderboard
    update_leaderboard(user_id, points=0, ai_score=0)
    return jsonify({"message":"Registered","user_id": user_id}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email'); password = data.get('password')
    if not (email and password):
        return jsonify({"error":"Email & password required"}), 400
    user = get_user_by_email(email)
    if not user or not verify_password(password, user['password_hash']):
        return jsonify({"error":"Invalid credentials"}), 401
    token = create_token(user_id=user['id'])
    return jsonify({"token": token, "user_id": user['id'], "role": user['role']})
