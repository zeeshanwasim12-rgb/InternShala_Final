import pymysql
from pymysql.cursors import DictCursor
from config import DB_HOST, DB_USER, DB_PASSWORD, DB_NAME

# Connect to MySQL
def get_db_connection():
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=DictCursor
    )

# ------------------------------
# USER OPERATIONS
# ------------------------------

def create_user(name, email, password_hash, role, university):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO users (name, email, password_hash, role, university)
        VALUES (%s, %s, %s, %s, %s)
    """
    cursor.execute(query, (name, email, password_hash, role, university))
    conn.commit()
    cursor.close()
    conn.close()
    return True

def get_user_by_email(email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

def get_user_by_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id=%s", (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

# ------------------------------
# INTERNSHIP OPERATIONS
# ------------------------------

def add_internship(employer_id, title, description, skills_required, duration, stipend, location):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO internships (employer_id, title, description, skills_required, duration, stipend, location)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (employer_id, title, description, skills_required, duration, stipend, location))
    conn.commit()
    cursor.close()
    conn.close()
    return True

def get_all_internships():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT i.*, u.name AS employer_name
        FROM internships i
        JOIN users u ON i.employer_id = u.id
        ORDER BY i.posted_at DESC
    """)
    internships = cursor.fetchall()
    cursor.close()
    conn.close()
    return internships

# ------------------------------
# APPLICATION OPERATIONS
# ------------------------------

def apply_for_internship(internship_id, student_id, resume_link):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO applications (internship_id, student_id, resume_link)
        VALUES (%s, %s, %s)
    """
    cursor.execute(query, (internship_id, student_id, resume_link))
    conn.commit()
    cursor.close()
    conn.close()
    return True

def get_applications_for_employer(employer_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        SELECT a.*, u.name AS student_name, u.university
        FROM applications a
        JOIN internships i ON a.internship_id = i.id
        JOIN users u ON a.student_id = u.id
        WHERE i.employer_id = %s
    """
    cursor.execute(query, (employer_id,))
    applications = cursor.fetchall()
    cursor.close()
    conn.close()
    return applications

# ------------------------------
# LEADERBOARD
# ------------------------------

def get_leaderboard():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.id, u.name, u.university, l.total_points, l.ai_score
        FROM leaderboard l
        JOIN users u ON l.user_id = u.id
        ORDER BY l.total_points DESC
    """)
    leaderboard = cursor.fetchall()
    cursor.close()
    conn.close()
    return leaderboard

def get_applications_for_student(student_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        SELECT a.*, i.title, i.company, i.location
        FROM applications a
        JOIN internships i ON a.internship_id = i.id
        WHERE a.student_id = %s
    """
    cursor.execute(query, (student_id,))
    applications = cursor.fetchall()
    cursor.close()
    conn.close()
    return applications
