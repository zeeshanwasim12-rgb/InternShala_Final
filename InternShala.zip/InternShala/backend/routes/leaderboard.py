from flask import Blueprint, jsonify
from models import get_leaderboard
leaderboard_bp = Blueprint('leaderboard_bp', __name__)

@leaderboard_bp.route('/', methods=['GET'])
def leaderboard():
    rows = get_leaderboard()
    # assign rank
    for i, r in enumerate(rows, start=1):
        r['rank'] = i
    return jsonify(rows)
