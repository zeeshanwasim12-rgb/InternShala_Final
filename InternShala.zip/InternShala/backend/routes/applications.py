from flask import Blueprint, request, jsonify
from models import apply_for_internship, get_applications_for_employer

applications_bp = Blueprint('applications_bp', __name__)

@applications_bp.route('/apply', methods=['POST'])
def apply():
    data = request.get_json() or {}
    student_id = data.get('student_id'); internship_id = data.get('internship_id'); resume_link = data.get('resume_link')
    if not (student_id and internship_id):
        return jsonify({"error":"Missing fields"}), 400
    aid = apply_to_internship(internship_id, student_id, resume_link)
    return jsonify({"message":"Applied","id":aid}), 201

@applications_bp.route('/student/<int:student_id>', methods=['GET'])
def student_apps(student_id):
    rows = get_applications_for_student(student_id)
    return jsonify(rows)
